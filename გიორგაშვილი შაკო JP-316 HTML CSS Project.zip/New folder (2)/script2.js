c.onst words = ['giorgi', 'luka', 'nika', 'otiko', 'amirani', 'miriani', 'aleqsandre', 'lasha', 'tazo', 'aleko'];//რანდომულად სახელების გენერირება
let currentWordIndex;
let timeLimit = 20;//ტაიმერი
let score = 0;
let timer;
function startGame() { //სტარტგეიმ ღილაკი
  currentWordIndex = 0;
  score = 0;
  updateScore();
  showWord();
  startTimer();
}
function showWord() {
  const wordDisplay = document.getElementById('word-display');
  wordDisplay.textContent = words[currentWordIndex];
}
function startTimer() {
  timer = setInterval(function () {
    timeLimit--;
    if (timeLimit <= 0) {
      clearInterval(timer);
      endGame();
    } else {
      updateTimer();
    }
  }, 1000);
}
function checkInput() {
  const wordInput = document.getElementById('word-input');
  const inputText = wordInput.value.trim().toLowerCase();
  const currentWord = words[currentWordIndex].toLowerCase();

  if (inputText === currentWord) {
    wordInput.value = '';
    currentWordIndex++;
    score++;

    if (currentWordIndex === words.length) {
      endGame();
  } else {
      showWord();
  }
    updateScore();
  }
}
function submitWord() {
  const wordInput = document.getElementById('word-input');
  const inputText = wordInput.value.trim().toLowerCase();
  const currentWord = words[currentWordIndex].toLowerCase();

  if (inputText === currentWord) {
    wordInput.value = '';
    currentWordIndex++;
    score++;

    if (currentWordIndex === words.length) {
      endGame();
  } else {
      showWord();
  }

    updateScore();
  }
}

function endGame() {
  clearInterval(timer);
  alert(`Game Over! Your score: ${score}`);
  resetGame();
}

function resetGame() {
  currentWordIndex = 0;
  timeLimit = 20;
  updateTimer();
}

function updateScore() {
  document.getElementById('current-score').textContent = score;//ქულა
}

function updateTimer() {
  document.getElementById('time-left').textContent = timeLimit;//დარჩენილი დრო
}

document.getElementById('word-input').addEventListener('input', checkInput);//წამოსული სიტყვები
