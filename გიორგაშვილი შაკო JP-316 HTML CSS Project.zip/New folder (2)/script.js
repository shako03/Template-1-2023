const secretNumber = Math.floor(Math.random() * 100) + 1;
let attempts = 0;
function checkGuess() {
const userGuess = parseInt(document.getElementById("inputBox").value);
if (isNaN(userGuess) || userGuess < 1 || userGuess > 100) {
 alert("გთხოვთ ჩაწეროთ რიცხვი 1 დან 100მდე (არც მეტი არც ნაკლები)");
 return;
    }
showPreloader();
    setTimeout(() => {
attempts++;
if (userGuess === secretNumber) {
document.getElementById("result").innerHTML = `ყოჩაღ შენ ეს შეძელი ${secretNumber} in ${attempts} ცდაში.`;
document.getElementById("result").style.color = "#4caf50";
disableInput();
} else {
document.getElementById("result").innerHTML = userGuess < secretNumber
    ? "low try again! ცადეთ ახლიდან."
    : "high tri again! ცადეთ ახლიდან.";
    document.getElementById("result").style.color = "#c603fc";//hex-ფერია GPT არარის არა <3
        }
    hidePreloader();
}, 1000);
}
function disableInput() {
document.getElementById("inputBox").disabled = true;
document.getElementById("submitBtn").disabled = true;
}
function showPreloader() {
 document.getElementById("preloader").style.display = "block";
}
function hidePreloader() {
   document.getElementById("preloader").style.display = "none";
}
